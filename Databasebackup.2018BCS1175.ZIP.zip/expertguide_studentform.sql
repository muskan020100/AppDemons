-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2020 at 06:56 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abesa2hs_dataritz_projects`
--

-- --------------------------------------------------------

--
-- Table structure for table `expertguide_studentform`
--

CREATE TABLE `expertguide_studentform` (
  `name` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `field` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `school` varchar(20) NOT NULL,
  `something` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expertguide_studentform`
--

INSERT INTO `expertguide_studentform` (`name`, `contact`, `city`, `field`, `email`, `school`, `something`) VALUES
('abes', '', 'ghz', '', 'shivank.18bcs1009@abes.ac.in', '', ''),
('shivank', '8265820722', 'meerut', 'pcm', 'shivank.18bcs1009@abes.ac.in', 'stems', 'unwciuencnwencdicn');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expertguide_studentform`
--
ALTER TABLE `expertguide_studentform`
  ADD PRIMARY KEY (`contact`,`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
