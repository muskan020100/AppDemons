<?php
$data=$_POST['data'];
$s=json_decode($data); //conversion to PHP object
$name=$s->name;
$uni=$s->uni;
$pvtgov=$s->pvtgov;
$courses=$s->courses;
$email=$s->email;
$city=$s->city;
$fee=$s->fee;
$sql="INSERT INTO expertguide_collegeform VALUES('$name','$uni','$pvtgov','$courses','$email','$city','$fee')";
//$cn=mysqli_connect("localhost","root","","abesa2hs_dataritz_projects") or die("Unable to connect");
$cn=mysqli_connect("103.76.228.244","abesa2hs_dr","123456.India","abesa2hs_dataritz_projects") or die("Unable to connect");
mysqli_query($cn,$sql) or die("Unable to insert record");
mysqli_close($cn);
echo "done";
?>